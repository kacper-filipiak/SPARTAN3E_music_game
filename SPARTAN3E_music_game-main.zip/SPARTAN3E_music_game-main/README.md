# SPARTAN3E_music_game
A project in VHDL developed on Xilinx Spartan 3E FPGA board. Main goal is creation of music game
