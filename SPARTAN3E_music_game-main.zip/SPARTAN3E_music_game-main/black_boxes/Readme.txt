Modu�y zawarte w tym archiwum zosta�y przygotowane dla potrzeb zaj�� z przedmiotu
�Uk�ady cyfrowe�, prowadzonego na Wydziale Elektroniki Politechniki Wroc�awskiej,
i s� udost�pnione wy��cznie dla prywatnych cel�w edukacyjnych. Inne ich u�ycie 
bez uzyskania zgody autora jest zabronione.

Modules contained in this archive were prepared for the course �Digital Systems�,
Wroclaw University of Technology, Faculty of Electronics, and are for private 
educational use only. Any other use is prohibited unless a separate permission 
was granted by the author.


Jaros�aw Sugier
jaroslaw.sugier@pwr.wroc.pl